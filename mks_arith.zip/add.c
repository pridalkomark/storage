/*	Mark o'Software: Command Line Arithmetic
 *	(C) 2024 Pridalko Mark
 *
 *	This software runs under the GNU GPL 3 license,
 *	it should be included with the program.
 */
#include <stdio.h> //i dont have to explain
#include <stdlib.h> 		   
//#include <windows.h> //for gui output and file output because of /NODEFAULTLIB

const int VERNUM = 7;

int main(int argc, char *argv[]){
	if(argc < 3){
		printf("Mark o'Software: Command Line Arithmetic: Addition\n(C) 2024 Pridalko Mark\nThis software is under the GNU GPL 3 license\nVersion %i\n\n", VERNUM);
		printf("Syntax: > [command] [float] [float]\n\n");
		printf("Error 1: Not enough arguments. Parsed in %i arguments, 2 needed.", argc - 1);
		return 1;
	}
	float result = atof(argv[1]) + atof(argv[2]);
	printf("\n%f", result);
	return 0;
}
